import java.util.Arrays;
import java.util.HashSet;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Set;

class InvalidBookIdException extends Exception {
    InvalidBookIdException(String id) {
        super("ID buku \"" + id + "\" tidak ditemukan di database.");
    }
}

class InvalidLoanDurationException extends Exception {
    InvalidLoanDurationException(int hari) {
        super("Lama peminjaman harus antara 1 – 14 hari, bukan " + hari + ".");
    }
}

public class LibraryLoan {

    private static final Set<String> VALID_BOOK_IDS =
            new HashSet<>(Arrays.asList("B001", "B002", "B003"));

    private static void processLoan() throws InvalidBookIdException, InvalidLoanDurationException {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.print("Masukkan nama Anda: ");
            String nama = sc.nextLine().trim();

            System.out.print("Masukkan ID buku: ");
            String bookId = sc.nextLine().trim().toUpperCase();

            if (!VALID_BOOK_IDS.contains(bookId)) {
                throw new InvalidBookIdException(bookId);
            }

            System.out.print("Masukkan lama peminjaman (hari): ");
            int hari = sc.nextInt();  

            if (hari < 1 || hari > 14) {
                throw new InvalidLoanDurationException(hari);
            }

            System.out.println("\n=== STRUK PEMINJAMAN ===");
            System.out.println("Nama         : " + nama);
            System.out.println("ID Buku      : " + bookId);
            System.out.println("Durasi       : " + hari + " hari");
            System.out.println("Status       : Berhasil dipinjam. Selamat membaca!");

        } finally {
            sc.close();
        }
    }
    public static void main(String[] args) {
        try {
            processLoan();
        } catch (InvalidBookIdException | InvalidLoanDurationException e) {
            System.err.println("Exception: " + e.getMessage());
        } catch (InputMismatchException e) {
            System.err.println("Exception: Input jumlah hari harus berupa bilangan bulat.");
        } catch (Exception e) {
            System.err.println("Exception tak terduga: " + e.getMessage());
        } finally {
            System.out.println("Program selesai.");
        }
    }
}
