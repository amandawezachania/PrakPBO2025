public class Driver {
    private String name;
    private Vehicle vehicle;
    private License license;

    public Driver(String name, Vehicle vehicle, String licenseNumber) {
        this.name = name;
        this.vehicle = vehicle;
        this.license = new License(licenseNumber);
    }

    public void displayInfo() {
        System.out.println("Nama Pengemudi: " + name);
        System.out.print("Status Mesin: ");
        vehicle.startEngine();

        if (vehicle instanceof Car) {
            System.out.println("Jenis Kendaraan: Mobil");
        } else if (vehicle instanceof Motorcycle) {
            System.out.println("Jenis Kendaraan: Motor");
        }

        System.out.println("Nomor Lisensi: " + license.getLicenseNumber());
        System.out.println("Tanggal Berlaku Lisensi: " + license.getValidUntil());
        System.out.println();
    }
}
