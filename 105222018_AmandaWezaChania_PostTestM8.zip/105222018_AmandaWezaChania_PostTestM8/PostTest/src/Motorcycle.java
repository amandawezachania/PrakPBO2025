public class Motorcycle extends Vehicle {
    @Override
    public void startEngine() {
        System.out.println("Mesin Motor Nyala");
    }
}
