public class Car extends Vehicle {
    @Override
    public void startEngine() {
        System.out.println("Mesin Mobil Nyala");
    }
}
