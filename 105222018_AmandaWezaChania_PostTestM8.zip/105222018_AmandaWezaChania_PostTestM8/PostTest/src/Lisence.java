import java.util.Calendar;
import java.util.Date;

public class License {
    private String licenseNumber;
    private Date validUntil;

    public License(String licenseNumber) {
        this.licenseNumber = licenseNumber;
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.YEAR, 5);
        this.validUntil = cal.getTime();
    }

    public String getLicenseNumber() {
        return licenseNumber;
    }

    public Date getValidUntil() {
        return validUntil;
    }
}
