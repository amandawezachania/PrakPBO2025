public class Main {
    public static void main(String[] args) {
        Driver driver1 = new Driver("Amanda", new Car(), "CAR-1234");
        Driver driver2 = new Driver("Haekal", new Motorcycle(), "MOTO-5678");

        driver1.displayInfo();
        driver2.displayInfo();
    }
}
