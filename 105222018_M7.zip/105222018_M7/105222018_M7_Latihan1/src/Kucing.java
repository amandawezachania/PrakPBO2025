public class Kucing extends Hewan {
    String suara = "Meong";
    void tampilkanSuara() {
        System.out.println("suara milik kelas Kucing : " + suara);
        System.out.println("suara milik kelas Hewan  : " + super.suara);
    }
}
