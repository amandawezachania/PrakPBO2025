public class MainLatihan1 {
    public static void main(String[] args) {
        Kucing kitty = new Kucing();
        kitty.tampilkanSuara();
    }
}
