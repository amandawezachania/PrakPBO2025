public class Hewan {
    String suara = "Suara hewan";
}
