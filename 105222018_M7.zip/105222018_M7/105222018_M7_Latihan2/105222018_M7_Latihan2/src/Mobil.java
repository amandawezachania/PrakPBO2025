public class Mobil extends Kendaraan {
    public Mobil() {
        super();                             
        System.out.println("Konstruktor Mobil dipanggil");
    }
}
