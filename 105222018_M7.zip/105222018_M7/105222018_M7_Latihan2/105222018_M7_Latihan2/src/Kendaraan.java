public class Kendaraan {
    public Kendaraan() {
        System.out.println("Konstruktor Kendaraan dipanggil");
    }
}
