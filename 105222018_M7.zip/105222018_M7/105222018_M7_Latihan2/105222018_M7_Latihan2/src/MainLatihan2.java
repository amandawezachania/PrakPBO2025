public class MainLatihan2 {
    public static void main(String[] args) {
        Mobil m = new Mobil(); 
    }
}
