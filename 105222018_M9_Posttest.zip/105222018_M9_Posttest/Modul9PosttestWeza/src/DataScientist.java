public class DataScientist extends Employee {
    public DataScientist(String name) {
        super(name);
    }

    @Override
    public double calculateSalary() {
        return 12000000;
    }

    @Override
    public double calculateSalary(boolean withBonus) {
        return withBonus ? 13000000 : 12000000;
    }
}