public class Intern extends Employee {
    public Intern(String name) {
        super(name);
    }

    @Override
    public double calculateSalary() {
        return 3000000;
    }

    @Override
    public double calculateSalary(boolean withBonus) {
        return withBonus ? 3500000 : 3000000;
    }
}