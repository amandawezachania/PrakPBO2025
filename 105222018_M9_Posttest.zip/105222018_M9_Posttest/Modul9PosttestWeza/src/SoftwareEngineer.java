public class SoftwareEngineer extends Employee {
    public SoftwareEngineer(String name) {
        super(name);
    }

    @Override
    public double calculateSalary() {
        return 10000000;
    }

    @Override
    public double calculateSalary(boolean withBonus) {
        return withBonus ? 11000000 : 10000000;
    }
}