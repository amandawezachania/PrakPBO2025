abstract class Employee {
    protected String name;

    public Employee(String name) {
        this.name = name;
    }

    public abstract double calculateSalary();

    public double calculateSalary(boolean withBonus) {
        if (withBonus) return calculateSalary() + 1000000;
        else return calculateSalary();
    }

    public void printInfo() {
        System.out.println("Employee: " + name);
    }
}