public class MainEmployee {
    public static void main(String[] args) {
        Employee[] employees = {
            new SoftwareEngineer("Amanda"),
            new DataScientist("Haekal"),
            new Intern("Pasha")
        };

        for (Employee emp : employees) {
            emp.printInfo();
            System.out.println("Gaji tanpa bonus: Rp" + emp.calculateSalary());
            System.out.println("Gaji dengan bonus: Rp" + emp.calculateSalary(true));
            System.out.println("----------------------");
        }
    }
}