import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Kendaraan> daftar = new ArrayList<>();

        daftar.add(new MobilPribadi("B 1234 ABC", "Toyota Avanza", 2022));
        daftar.add(new Bus("B 9876 CDE", "Mercedes-Benz OH 1526", 2019));
        daftar.add(new Truk("B 5555 FGH", "Mitsubishi Fuso", 2020, 12_000)); // 12 ton

        int lamaSewa = 3; 
        for (Kendaraan k : daftar) {
            System.out.println("================================");
            k.tampilkanInfo();
            System.out.println("Perlu Supir   : " + (k.perluSupir() ? "Ya" : "Tidak"));
            System.out.println("Biaya " + lamaSewa + " hari: Rp "
                    + String.format("%,.0f", k.hitungBiayaSewa(lamaSewa)));
        }
    }
}
