public interface DapatDisewa {
    double  hitungBiayaSewa(int hari);
    boolean perluSupir();
}
