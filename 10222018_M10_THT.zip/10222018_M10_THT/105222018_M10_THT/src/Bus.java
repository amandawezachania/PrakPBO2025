public class Bus extends Kendaraan implements DapatDisewa {

    private static final double TARIF_HARIAN = 1_000_000;

    public Bus(String platNomor, String merk, int tahunProduksi) {
        super(platNomor, merk, tahunProduksi);
    }

    @Override
    public double hitungBiayaSewa(int hari) {
        return TARIF_HARIAN * hari;
    }

    @Override
    public boolean perluSupir() {
        return true;
    }
}
