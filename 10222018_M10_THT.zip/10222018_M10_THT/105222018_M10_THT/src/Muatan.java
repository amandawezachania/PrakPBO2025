public interface Muatan {
    /** @return kapasitas muatan dalam kilogram */
    double kapasitasMuatan();
}
