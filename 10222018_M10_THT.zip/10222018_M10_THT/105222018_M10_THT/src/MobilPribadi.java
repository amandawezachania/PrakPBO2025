public class MobilPribadi extends Kendaraan implements DapatDisewa {

    private static final double TARIF_HARIAN = 300_000; 

    public MobilPribadi(String platNomor, String merk, int tahunProduksi) {
        super(platNomor, merk, tahunProduksi);
    }

    @Override
    public double hitungBiayaSewa(int hari) {
        return TARIF_HARIAN * hari;
    }
    @Override
    public boolean perluSupir() {
        return false;
    }
}
