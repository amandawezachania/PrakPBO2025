public class Truk extends Kendaraan implements DapatDisewa, Muatan {

    private static final double TARIF_HARIAN = 800_000;
    private final double kapasitasKg; 

    public Truk(String platNomor, String merk, int tahunProduksi, double kapasitasKg) {
        super(platNomor, merk, tahunProduksi);
        this.kapasitasKg = kapasitasKg;
    }

    @Override
    public double hitungBiayaSewa(int hari) {
        return TARIF_HARIAN * hari;
    }

    @Override
    public boolean perluSupir() {
        return true; 
    }

    @Override
    public double kapasitasMuatan() {
        return kapasitasKg;
    }

    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Kapasitas Muatan: " + kapasitasKg + " kg");
    }
}
