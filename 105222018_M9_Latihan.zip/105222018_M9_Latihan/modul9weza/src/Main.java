public class Main {
    public static void main(String[] args) {
        PaymentMethod[] payments = new PaymentMethod[3];
        payments[0] = new CreditCard();
        payments[1] = new EWallet();
        payments[2] = new BankTransfer();

        System.out.println("=== Pembayaran Default (IDR) ===");
        for (PaymentMethod payment : payments) {
            payment.processPayment(100000);
        }

        System.out.println("\n=== Pembayaran dengan Mata Uang Spesifik ===");
        payments[0].processPayment(100000, "USD");
        payments[1].processPayment(200000, "EUR");
        payments[2].processPayment(150000, "JPY");
    }
}