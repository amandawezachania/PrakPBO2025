public class BankTransfer extends PaymentMethod {
    @Override
    public void processPayment(double amount) {
        System.out.println("Bank Transfer payment: " + amount + " IDR");
    }

    @Override
    public void processPayment(double amount, String currency) {
        System.out.println("Bank Transfer payment: " + amount + " " + currency);
    }
}