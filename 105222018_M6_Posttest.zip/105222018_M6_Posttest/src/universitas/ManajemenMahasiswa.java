package universitas;

import java.util.ArrayList;

public class ManajemenMahasiswa {
    private ArrayList<Mahasiswa> daftar = new ArrayList<>();
    public void tambahMahasiswa(Mahasiswa m) {
        daftar.add(m);
    }
    public void tampilkanSemua() {
        if (daftar.isEmpty()) {
            System.out.println("Belum ada data mahasiswa.");
            return;
        }
        System.out.println("DAFTAR MAHASISWA:");
        for (Mahasiswa m : daftar) {
            m.tampilkanData();
        }
    }
    public void tampilkanIPKTertinggi() {
        if (daftar.isEmpty()) {
            System.out.println("Belum ada data mahasiswa.");
            return;
        }
        Mahasiswa terbaik = daftar.get(0);
        for (Mahasiswa m : daftar) {
            if (m.getIpk() > terbaik.getIpk()) terbaik = m;
        }
        System.out.println("Mahasiswa dengan IPK tertinggi:");
        terbaik.tampilkanData();
    }
}
