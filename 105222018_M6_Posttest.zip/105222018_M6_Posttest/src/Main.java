import universitas.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ManajemenMahasiswa mm = new ManajemenMahasiswa();

        while (true) {
            System.out.println("\n=== MENU ===");
            System.out.println("1. Tambah Mahasiswa");
            System.out.println("2. Tampilkan Semua Mahasiswa");
            System.out.println("3. Tampilkan Mahasiswa dgn IPK Tertinggi");
            System.out.println("4. Keluar");
            System.out.print("Pilih: ");
            String pilihan = sc.nextLine();

            switch (pilihan) {
                case "1":
                    System.out.print("Masukkan NIM   : "); String nim = sc.nextLine();
                    System.out.print("Masukkan Nama  : "); String nama = sc.nextLine();
                    System.out.print("Masukkan Prodi : "); String prodi = sc.nextLine();
                    System.out.print("Masukkan IPK   : "); double ipk = Double.parseDouble(sc.nextLine());
                    mm.tambahMahasiswa(new Mahasiswa(nim, nama, prodi, ipk));
                    System.out.println("Data berhasil ditambahkan!");
                    break;
                case "2":
                    mm.tampilkanSemua();
                    break;
                case "3":
                    mm.tampilkanIPKTertinggi();
                    break;
                case "4":
                    System.out.println("Program selesai.");
                    sc.close();
                    return;
                default:
                    System.out.println("Pilihan tidak valid!");
            }
        }
    }
}
