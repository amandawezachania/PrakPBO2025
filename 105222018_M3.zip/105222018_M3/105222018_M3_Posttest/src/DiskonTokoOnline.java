import java.util.InputMismatchException;
import java.util.Scanner;

public class DiskonTokoOnline {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.print("Masukkan total belanja (Rp): ");
            double totalBelanja = sc.nextDouble();
            sc.nextLine();                                   

            System.out.print("Tipe member (Platinum/Gold/Silver/None): ");
            String member = sc.nextLine().trim().toLowerCase();

            if (totalBelanja < 0) {
                System.err.println("Error: Total belanja tidak boleh negatif.");
                return;
            }

            double diskonUtama;    
            if (totalBelanja > 500_000) {
                diskonUtama = 20;
            } else if (totalBelanja >= 250_000) {
                diskonUtama = 10;
            } else {
                diskonUtama = 0;
            }
            double potonganUtama = totalBelanja * diskonUtama / 100;
            double subtotal      = totalBelanja - potonganUtama;

            double diskonMember;  
            switch (member) {
                case "platinum": diskonMember = 5; break;
                case "gold":     diskonMember = 3; break;
                case "silver":   diskonMember = 2; break;
                case "none":     diskonMember = 0; break;
                default:
                    System.err.println("Error: Kategori member tidak dikenal."); 
                    return;
            }
            double potonganMember = subtotal * diskonMember / 100;
            double totalBayar     = subtotal - potonganMember;

            boolean dapatDiskon = (diskonUtama > 0) || (diskonMember > 0);
            String pesanDiskon  = dapatDiskon ? "Anda mendapatkan diskon." 
                                               : "Anda tidak mendapatkan diskon.";
            System.out.println("\n=== RINCIAN PEMBAYARAN ===");
            System.out.printf("Total belanja awal     : Rp%,.0f%n", totalBelanja);
            System.out.printf("Diskon utama (%.0f%%)   : Rp%,.0f%n", diskonUtama, potonganUtama);
            System.out.printf("Diskon member (%.0f%%)  : Rp%,.0f%n", diskonMember, potonganMember);
            System.out.printf("Total yang harus dibayar: Rp%,.0f%n", totalBayar);
            System.out.println(pesanDiskon);

        } catch (InputMismatchException e) {
            System.err.println("Error: Input angka tidak valid.");
        } finally {
            sc.close();
        }
    }
}
