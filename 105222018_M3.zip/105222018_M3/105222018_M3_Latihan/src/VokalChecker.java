import java.util.Scanner;

public class VokalChecker {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("Masukkan kalimat: ");
        String kalimat = sc.nextLine().toLowerCase();

        int hitungVokal = 0;
        for (int i = 0; i < kalimat.length(); i++) {
            char c = kalimat.charAt(i);
            if (c == 'a' || c == 'i' || c == 'u' || c == 'e' || c == 'o') {
                hitungVokal++;          
            } else {
            }
        }

        switch (hitungVokal % 2) {
            case 0:
                System.out.println("Jumlah vokal genap");
                break;
            default:
                System.out.println("Jumlah vokal ganjil");
        }

        System.out.print("Karakter terbalik: ");
        for (char ch : new StringBuilder(kalimat).reverse().toString().toCharArray()) {
            System.out.print(ch);
        }
        System.out.println();

        sc.close();
    }
}
