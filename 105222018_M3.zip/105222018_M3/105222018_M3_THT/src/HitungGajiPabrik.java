import java.util.InputMismatchException;
import java.util.Locale;
import java.util.Scanner;

public class HitungGajiPabrik {

    private static final int RATE_PAGI  = 20000;
    private static final int RATE_SIANG = 22000;
    private static final int RATE_MALAM = 25000;

    private static final double OVERTIME_MULTIPLIER = 1.5;   
    private static final int    ABSENT_PENALTY      = 100_000;
    private static final double UNDER_30H_PENALTY   = 0.10;  

    public static void main(String[] args) {

        Locale.setDefault(new Locale("id", "ID")); 
        Scanner sc = new Scanner(System.in);
        boolean lanjut = true;

        System.out.println("=== PROGRAM HITUNG GAJI KARYAWAN ===");

        while (lanjut) {
            try {
                System.out.print("\nID Karyawan          : ");
                String id = sc.nextLine().trim();

                System.out.print("Nama                 : ");
                String nama = sc.nextLine().trim();

                System.out.print("Shift (pagi/siang/malam): ");
                String shift = sc.nextLine().trim().toLowerCase();

                if (!(shift.equals("pagi") || shift.equals("siang") || shift.equals("malam"))) {
                    System.err.println("Shift tidak valid! (harus 'pagi', 'siang', atau 'malam')");
                    continue;
                }

                System.out.print("Total jam kerja/minggu: ");
                double jamKerja = sc.nextDouble();

                if (jamKerja < 0 || jamKerja > 168) {             
                    System.err.println("Jam kerja tidak masuk akal!");
                    sc.nextLine(); 
                    continue;
                }

                System.out.print("Jumlah hari absen (0‑7): ");
                int hariAbsen = sc.nextInt();
                sc.nextLine(); 

                if (hariAbsen < 0 || hariAbsen > 7) {
                    System.err.println("Jumlah hari absen tidak valid!");
                    continue;
                }
                int tarifPerJam;
                switch (shift) {
                    case "pagi":  tarifPerJam = RATE_PAGI;  break;
                    case "siang": tarifPerJam = RATE_SIANG; break;
                    default:      tarifPerJam = RATE_MALAM; 
                }

                double jamNormal  = Math.min(jamKerja, 40);
                double jamLembur  = Math.max(0, jamKerja - 40);

                double gajiNormal = jamNormal * tarifPerJam;
                double gajiLembur = jamLembur * tarifPerJam * OVERTIME_MULTIPLIER;
                double gajiKotor  = gajiNormal + gajiLembur;

                double potonganKurangJam = (jamKerja < 30) ? gajiKotor * UNDER_30H_PENALTY : 0;
                double potonganAbsen     = hariAbsen * ABSENT_PENALTY;

                double gajiBersih = gajiKotor - potonganKurangJam - potonganAbsen;

                System.out.println("\n----- LAPORAN GAJI -----");
                System.out.printf("ID / Nama       : %s / %s%n", id, nama);
                System.out.printf("Shift           : %s (Rp%,d / jam)%n", shift, tarifPerJam);
                System.out.printf("Jam normal      : %.1f jam  → Rp%,.0f%n", jamNormal, gajiNormal);
                System.out.printf("Jam lembur      : %.1f jam  → Rp%,.0f%n", jamLembur, gajiLembur);
                System.out.printf("Gaji kotor      : Rp%,.0f%n", gajiKotor);
                System.out.printf("Pot. <30 jam    : Rp%,.0f%n", potonganKurangJam);
                System.out.printf("Pot. absen (%d) : Rp%,.0f%n", hariAbsen, potonganAbsen);
                System.out.printf(">> GAJI BERSIH  : Rp%,.0f%n", gajiBersih);

            } catch (InputMismatchException e) {
                System.err.println("Input numerik tidak valid!");
                sc.nextLine(); 
                continue;
            }

            System.out.print("\nInput karyawan lain? (y/n) : ");
            String jawab = sc.nextLine().trim().toLowerCase();
            if (!jawab.equals("y")) {
                lanjut = false;
            }
        }

        System.out.println("\nProgram selesai. Terima kasih.");
        sc.close();
    }
}
