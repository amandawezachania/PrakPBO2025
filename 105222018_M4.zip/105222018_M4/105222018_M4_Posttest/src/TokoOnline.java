class Produk {
    private String kodeProduk;
    private String namaProduk;
    private double harga;
    private int stok;

    public Produk(String kodeProduk, String namaProduk, double harga, int stok) {
        this.kodeProduk = kodeProduk;
        this.namaProduk = namaProduk;
        this.harga      = harga;
        this.stok       = stok;
    }

    public void tampilkanInfoProduk() {
        System.out.printf("Produk [%s] %s | Harga: Rp%,.0f | Stok: %d%n",
                          kodeProduk, namaProduk, harga, stok);
    }

    public boolean kurangiStok(int jumlah) {
        if (stok >= jumlah) {
            stok -= jumlah;
            return true;
        }
        return false;
    }

    public double getHarga()   { return harga;     }
    public String getNama()    { return namaProduk;}
}
class Pelanggan {
    private String idPelanggan;
    private String nama;
    private String email;
    private double saldo;

    public Pelanggan(String idPelanggan, String nama, String email, double saldo) {
        this.idPelanggan = idPelanggan;
        this.nama        = nama;
        this.email       = email;
        this.saldo       = saldo;
    }

    public void tampilkanInfoPelanggan() {
        System.out.printf("Pelanggan [%s] %s | Saldo: Rp%,.0f | Email: %s%n",
                          idPelanggan, nama, saldo, email);
    }

    public void topUpSaldo(double jumlah)   { saldo += jumlah; }
    public boolean kurangiSaldo(double jml) {
        if (saldo >= jml) { saldo -= jml; return true; }
        return false;
    }

    public double getSaldo()       { return saldo; }
    public String getNama()        { return nama;  }
}
class Transaksi {
    private String idTransaksi;
    private Pelanggan pelanggan;
    private Produk produk;
    private int jumlahBeli;
    private double totalHarga;

    public Transaksi(String idTransaksi, Pelanggan pelanggan,
                     Produk produk, int jumlahBeli) {
        this.idTransaksi = idTransaksi;
        this.pelanggan   = pelanggan;
        this.produk      = produk;
        this.jumlahBeli  = jumlahBeli;
        this.totalHarga  = produk.getHarga() * jumlahBeli;
    }

    public boolean prosesTransaksi() {
        if (produk.kurangiStok(jumlahBeli)) {
            if (pelanggan.kurangiSaldo(totalHarga)) {
                System.out.println("Transaksi berhasil!");
                return true;
            } else {
                System.out.println("Gagal: Saldo tidak cukup.");
                produk.kurangiStok(-jumlahBeli); 
            }
        } else {
            System.out.println("Gagal: Stok produk habis.");
        }
        return false;
    }

    public void tampilkanDetailTransaksi() {
        System.out.println("\n=== Detail Transaksi ===");
        System.out.printf("ID       : %s%n", idTransaksi);
        System.out.printf("Pembeli  : %s%n", pelanggan.getNama());
        System.out.printf("Produk   : %s%n", produk.getNama());
        System.out.printf("Jumlah   : %d%n", jumlahBeli);
        System.out.printf("Total    : Rp%,.0f%n", totalHarga);
    }
}
public class TokoOnline {
    public static void main(String[] args) {
        Produk p1 = new Produk("P001", "Headset", 150_000, 10);
        Pelanggan c1 = new Pelanggan("C001", "Budi", "budi@mail.com", 500_000);

        p1.tampilkanInfoProduk();
        c1.tampilkanInfoPelanggan();

        Transaksi t1 = new Transaksi("T001", c1, p1, 3);
        if (t1.prosesTransaksi()) {
            t1.tampilkanDetailTransaksi();
        }

        System.out.println("\n-- Kondisi setelah transaksi --");
        c1.tampilkanInfoPelanggan();
        p1.tampilkanInfoProduk();
    }
}
