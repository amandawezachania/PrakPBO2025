public class Main {
    public static void main(String[] args) {
        Mahasiswa mhs1 = new Mahasiswa("Amanda", "105222018", "Informatika", 3.45);
        mhs1.tampilkanInfo();
        System.out.println("Lulus? " + mhs1.cekLulus());  
    }
}
