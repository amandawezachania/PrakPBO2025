public class Employee extends Person {
    private double salary;

    public Employee(String n, int a, double s) {
        super(n, a);   // panggil konstruktor Person
        salary = s;
    }

    @Override
    public void display() {
        super.display();                // cetak nama & umur
        System.out.println("Salary: " + salary);
    }
}
