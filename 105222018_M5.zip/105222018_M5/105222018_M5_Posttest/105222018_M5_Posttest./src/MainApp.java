public class MainApp {
    public static void main(String[] args) {
        Employee emp = new Employee("Alice", 25, 5_000.0);
        emp.display();   // tampilkan nama, umur, gaji
    }
}
