import librarysystem.Buku;
import librarysystem.Perpustakaan;
import librarysystem.User;

public class Main {
    public static void main(String[] args) {

        Perpustakaan perpustakaan = new Perpustakaan(10);

        perpustakaan.tambahBuku(new Buku("Laskar Pelangi",    "Andrea Hirata", 2005));
        perpustakaan.tambahBuku(new Buku("Bumi Manusia",      "Pramoedya A. T.", 1980));
        perpustakaan.tambahBuku(new Buku("Atomic Habits",     "James Clear", 2018));

        perpustakaan.tampilkanBuku();  

        User alice = new User("Alice", "U001");
        User bob   = new User("Bob",   "U002");

        Buku bukuAtomic = new Buku("Dummy", "N/A", 0); 

        Buku target1 = new Buku("Temp", "N/A", 0); 
        target1 = null;                             
        alice.pinjamBuku(getBukuByJudul(perpustakaan, "Atomic Habits"));

        bob.pinjamBuku(getBukuByJudul(perpustakaan, "Atomic Habits"));

        perpustakaan.tampilkanBuku();  
        bob.pinjamBuku(getBukuByJudul(perpustakaan, "Atomic Habits"));

        perpustakaan.tampilkanBuku();   
    }
    private static Buku getBukuByJudul(Perpustakaan perpustakaan, String judul) {
        try {
            java.lang.reflect.Field f = Perpustakaan.class.getDeclaredField("koleksiBuku");
            f.setAccessible(true);
            Buku[] arr = (Buku[]) f.get(perpustakaan);
            for (Buku b : arr) {
                if (b != null && b.getJudul().equalsIgnoreCase(judul)) {
                    return b;
                }
            }
        } catch (Exception e) { /* abaikan */ }
        return null;
    }
}
