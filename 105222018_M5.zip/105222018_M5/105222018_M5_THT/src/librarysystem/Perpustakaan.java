package librarysystem;
public class Perpustakaan {
    private final Buku[] koleksiBuku;
    private       int    jumlah;         
    public Perpustakaan(int kapasitas) {
        koleksiBuku = new Buku[kapasitas];
        jumlah      = 0;
    }
    public void tambahBuku(Buku buku) {
        if (jumlah < koleksiBuku.length) {
            koleksiBuku[jumlah++] = buku;
        } else {
            System.out.println("Koleksi penuh! Tidak dapat menambah buku lagi.");
        }
    }
    public void tampilkanBuku() {
        System.out.println("=== Daftar Buku Perpustakaan ===");
        for (int i = 0; i < jumlah; i++) {
            System.out.printf("%02d) %s%n", i + 1, koleksiBuku[i]);
        }
        System.out.println("--------------------------------");
        System.out.println("Total tersedia : " + Buku.getJumlahBukuTersedia());
        System.out.println();
    }
}
