package librarysystem;

public class User {

    private String nama;
    private String idUser;
    public User(String nama, String idUser) {
        this.nama   = nama;
        this.idUser = idUser;
    }
    public String getNama()   { return nama; }
    public String getIdUser() { return idUser; }
    public void pinjamBuku(Buku buku) {
        boolean sukses = buku.pinjamBuku();
        if (sukses) {
            System.out.printf("%s berhasil meminjam %s%n", nama, buku.getJudul());
        } else {
            System.out.printf("Maaf %s, buku \"%s\" sedang dipinjam orang lain.%n",
                              nama, buku.getJudul());
        }
    }
    public void kembalikanBuku(Buku buku) {
        boolean sukses = buku.kembalikanBuku();
        if (sukses) {
            System.out.printf("%s mengembalikan %s%n", nama, buku.getJudul());
        } else {
            System.out.printf("Buku \"%s\" tidak sedang dipinjam, %s tidak perlu mengembalikannya.%n",
                              buku.getJudul(), nama);
        }
    }
}
