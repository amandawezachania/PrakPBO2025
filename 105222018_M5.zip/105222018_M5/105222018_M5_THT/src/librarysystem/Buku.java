package librarysystem;
public class Buku {
    private String  judul;
    private String  penulis;
    private int     tahunTerbit;
    private boolean statusDipinjam;
    private static int jumlahBukuTersedia = 0;
    public Buku(String judul, String penulis, int tahunTerbit) {
        this.judul        = judul;
        this.penulis      = penulis;
        this.tahunTerbit  = tahunTerbit;
        this.statusDipinjam = false;        
        jumlahBukuTersedia++;             
    }
    public String  getJudul()       { return judul; }
    public void    setJudul(String j) { this.judul = j; }

    public String  getPenulis()     { return penulis; }
    public void    setPenulis(String p) { this.penulis = p; }

    public int     getTahunTerbit() { return tahunTerbit; }
    public void    setTahunTerbit(int t) { this.tahunTerbit = t; }

    public boolean isDipinjam()     { return statusDipinjam; }
    public boolean pinjamBuku() {
        if (!statusDipinjam) {
            statusDipinjam = true;
            jumlahBukuTersedia--;
            return true;
        }
        return false;  
    }
    public boolean kembalikanBuku() {
        if (statusDipinjam) {
            statusDipinjam = false;
            jumlahBukuTersedia++;
            return true;
        }
        return false;  
    }
    public static int getJumlahBukuTersedia() {
        return jumlahBukuTersedia;
    }
    @Override
    public String toString() {
        return String.format(
            "\"%s\" oleh %s (%d) - %s",
            judul, penulis, tahunTerbit,
            statusDipinjam ? "Sedang DIPINJAM" : "Tersedia"
        );
    }
}
