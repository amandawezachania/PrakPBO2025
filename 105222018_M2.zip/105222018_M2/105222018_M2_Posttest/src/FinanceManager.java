import java.util.InputMismatchException;
import java.util.Scanner;
import java.text.DecimalFormat;

public class FinanceManager {

    private static final DecimalFormat df = new DecimalFormat("Rp#,##0");

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        try {
            System.out.print("Nama                 : ");
            String nama = sc.nextLine().trim();

            System.out.print("Usia (tahun)         : ");
            int usia = sc.nextInt();

            System.out.print("Jumlah uang (Rp)     : ");
            double uang = sc.nextDouble();

            System.out.print("Pengeluaran harian (Rp): ");
            double pengeluaranHarian = sc.nextDouble();

            double usiaToDouble = (double) usia;   
            int    uangToInt    = (int) uang;      

            double sisa30Hari = uang - (pengeluaranHarian * 30);
            double bulanBertahan = uang / (pengeluaranHarian * 30);

            String statusKeuangan;
            if (bulanBertahan < 1) {
                statusKeuangan = "PERINGATAN: Keuangan Anda kurang stabil!";
            } else if (bulanBertahan > 6) {
                statusKeuangan = "Keuangan Anda dalam kondisi aman.";
            } else {
                statusKeuangan = "Keuangan Anda cukup stabil, teruskan pengelolaan yang baik.";
            }

            boolean usiaLebih30            = usia > 30;
            boolean usiaLebih30DanUang10jt = (usia > 30) && (uang > 10_000_000);
            boolean usiaKurang30AtauUang5  = (usia < 30) || (uang > 5_000_000);

            System.out.print("Jumlah hutang (Rp)   : ");
            double hutang = sc.nextDouble();

            double hutangAbs           = Math.abs(hutang);
            int    pengeluaranCeil     = (int) Math.ceil(pengeluaranHarian);
            int    bonusTakTerduga     = 100_000 + (int) (Math.random() * (1_000_000 - 100_000 + 1));

            double totalSetelahSemua   = sisa30Hari + bonusTakTerduga;

            System.out.println("\n=== LAPORAN KEUANGAN PRIBADI ===");
            System.out.println("Nama                          : " + nama);
            System.out.println("Usia                          : " + usia + " tahun");
            System.out.println("Uang yang dimiliki            : " + df.format(uangToInt));
            System.out.println("Pengeluaran harian rata-rata  : " + df.format(pengeluaranHarian));
            System.out.println("Sisa uang dalam 30 hari       : " + df.format(sisa30Hari));
            System.out.printf("Estimasi bulan bertahan       : %.2f bulan%n", bulanBertahan);
            System.out.println("Status Keuangan               : " + statusKeuangan);

            System.out.println("\n-- Analisis Perbandingan & Logika --");
            System.out.println("Apakah usia > 30?                          " + usiaLebih30);
            System.out.println("Apakah usia > 30 DAN uang > 10 juta?       " + usiaLebih30DanUang10jt);
            System.out.println("Apakah usia < 30 ATAU uang > 5 juta?       " + usiaKurang30AtauUang5);

            System.out.println("\n-- Detail Tambahan --");
            System.out.println("Nilai absolut dari hutang      : " + df.format(hutangAbs));
            System.out.println("Pengeluaran harian (dibulatkan): " + df.format(pengeluaranCeil));
            System.out.println("Bonus tak terduga              : " + df.format(bonusTakTerduga));
            System.out.println("Total uang setelah 30 hari + bonus: " + df.format(totalSetelahSemua));

            System.out.println("\n-- Hasil Konversi Tipe Data --");
            System.out.println("Usia (double)   : " + usiaToDouble);
            System.out.println("Uang (int)      : " + uangToInt);

        } catch (InputMismatchException e) {
            System.err.println("Input tidak valid! Pastikan memasukkan angka pada kolom yang diminta.");
        } finally {
            sc.close(); 
        }
    }
}
