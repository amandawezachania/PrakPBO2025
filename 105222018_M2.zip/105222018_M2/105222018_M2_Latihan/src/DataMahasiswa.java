import java.util.Scanner;

public class DataMahasiswa {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        try {
            System.out.print("Nama      : ");
            String nama = sc.nextLine();

            System.out.print("NIM       : ");
            String nim  = sc.nextLine();

            System.out.print("Usia (th) : ");
            int usia   = sc.nextInt();

            System.out.print("Tinggi (cm): ");
            double tinggi = sc.nextDouble();

            System.out.println("\n=== DATA MAHASISWA ===");
            System.out.printf("Nama   : %s%n", nama);
            System.out.printf("NIM    : %s%n", nim);
            System.out.printf("Usia   : %d tahun%n", usia);
            System.out.printf("Tinggi : %.1f cm%n", tinggi);

            double hasilAritmatika = (usia * 2) + 10 / 5.0 - 3; 
            System.out.printf("%nHasil (usia*2 + 10/5 - 3) = %.2f%n", hasilAritmatika);

            boolean usiaDiAtas18 = usia > 18;
            System.out.println("Usia > 18 ?                     : " + usiaDiAtas18);

            boolean syaratUmurTinggi = (usia > 18) && (tinggi > 160);
            System.out.println("(Usia > 18) && (Tinggi > 160) ? : " + syaratUmurTinggi);

            double usiaToDouble = (double) usia;     
            int tinggiToInt     = (int) tinggi;       

            System.out.printf("%nCasting usia   → double : %.1f%n", usiaToDouble);
            System.out.printf("Casting tinggi → int    : %d%n", tinggiToInt);

        } finally {
            sc.close();  
        }
    }
}
