import java.text.DecimalFormat;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class StudentGradeManager {

    private static final DecimalFormat df2 = new DecimalFormat("#0.00");

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        try {
            System.out.print("Nama          : ");
            String nama = sc.nextLine().trim();

            System.out.print("NIM           : ");
            String nim = sc.nextLine().trim();

            System.out.print("Usia (tahun)  : ");
            int usia = sc.nextInt();

            System.out.print("Jumlah mata kuliah yang diambil: ");
            int jmlMk = sc.nextInt();
            sc.nextLine(); 
            double totalNilai = 0.0;
            for (int i = 1; i <= jmlMk; i++) {
                double nilai;
                while (true) {
                    System.out.printf("   Nilai mata kuliah ke‑%d (0.0–4.0): ", i);
                    nilai = sc.nextDouble();
                    if (nilai >= 0 && nilai <= 4) break;
                    System.out.println("      ⚠️  Nilai harus di antara 0.0 dan 4.0, coba lagi.");
                }
                totalNilai += nilai;
            }

            double ipk = totalNilai / jmlMk;

            boolean usiaLebih22                  = usia > 22;
            boolean ipkTinggiDanMkBanyak         = (ipk >= 3.5) && (jmlMk > 4);
            boolean ipkRendahAtauMkSedikit       = (ipk < 2.5) || (jmlMk < 4);

            int nomorAntrian = new Random().nextInt(100) + 1;  

            System.out.println("\n===== LAPORAN AKADEMIK MAHASISWA =====");
            System.out.println("Nama                : " + nama);
            System.out.println("NIM                 : " + nim);
            System.out.println("Usia                : " + usia + " tahun");
            System.out.println("Jumlah Mata Kuliah  : " + jmlMk);
            System.out.println("IPK (rata‑rata)     : " + df2.format(ipk));

            System.out.println("\n-- Evaluasi Logika --");
            System.out.println("Apakah usia > 22?                                       " + usiaLebih22);
            System.out.println("Apakah IPK ≥ 3.5 DAN jumlah MK > 4?                     " + ipkTinggiDanMkBanyak);
            System.out.println("Apakah IPK < 2.5 ATAU jumlah MK < 4?                    " + ipkRendahAtauMkSedikit);

            System.out.println("\nNomor antrian konsultasi akademik (acak): " + nomorAntrian);
            System.out.println("=========================================");

        } catch (InputMismatchException e) {
            System.err.println("\nInput tidak valid! Pastikan angka dimasukkan pada kolom yang diminta.");
        } finally {
            sc.close();   
        }
    }
}
